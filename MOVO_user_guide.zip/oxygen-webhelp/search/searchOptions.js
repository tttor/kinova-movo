// Expanded from webhelp.search.ranking ANT property
var webhelpSearchRanking = true;

// Expanded from webhelp.enable.search.autocomplete ANT property
var webhelpEnableSearchAutocomplete = true;

// Expanded from webhelp.search.enable.pagination ANT property
var webhelpEnableSearchPagination = true;

// Expanded from webhelp.search.page.numberOfItems ANT property
var webhelpSearchNumberOfItems = 10;
